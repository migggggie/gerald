Before you play here are some things you should know:
  1.
    Repl might lag sometimes, so when you click, CLICK WITH INTENT! It might help to shimmy the mouse as you hold the button too! (I've found that for whatever reason, my trackpad registers better, but it depends on what your setup is)

  2. 
    You get to pick from 6 people. You can go on first dates with ALL of them. Once you go on a second date with someone however, you are no longer able to go on a first date with anyone else unless you rerun the program because you have decided to commit to this person.
  
  3.
    PLAY THIS MUSIC ON LOOP IN THE BACKGROUND BC REPL DOESN'T SUPPORT AUDIO MIXER
    https://youtu.be/JH5OBD5oJYk
    unless you hate it...


add You: to its kinda spooky isaacd2